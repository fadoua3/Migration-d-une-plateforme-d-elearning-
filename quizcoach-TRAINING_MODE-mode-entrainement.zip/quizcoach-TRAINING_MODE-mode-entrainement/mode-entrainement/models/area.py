# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Area(models.Model):
    _name = 'training.area'
    _description = 'area'

    name = fields.Char(string='Nom')
    website_id = fields.Many2one('website', required=True)
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company)