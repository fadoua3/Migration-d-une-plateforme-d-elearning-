# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Mode_ue(models.Model):
     _name = 'training.mode.ue'
     _description = 'UE'

     name = fields.Char(string='Name')
     ue_data_base_id = fields.Many2one('training.mode.database', string='Base de données')
     website_id = fields.Many2one('website', required=True)
     company_id = fields.Many2one('res.company', string='Company', required=True,
                                  default=lambda self: self.env.company)

