# -*- coding: utf-8 -*-

from odoo import models, fields, api


class data_base(models.Model):
     _name = 'training.mode.database'
     _description = 'mode_entrainement.mode_entrainement'


     name = fields.Char()
     online = fields.Integer(string='Online')
     price = fields.Float(string='Price')
     entity_id = fields.Many2one('training.mode.entities', string='Entity')
     domaine_id = fields.Many2one('training.mode.domaine', string='Domaine')
     year_id = fields.Many2one('training.mode.year', string='Year')
     ue_id = fields.One2many('training.mode.ue', 'ue_data_base_id')
     website_id = fields.Many2one('website', required=True)
     company_id = fields.Many2one('res.company', string='Company', required=True,
                                  default=lambda self: self.env.company)

     # @api.depends('ue_id')
     # def _compute_ue(self):
     #      for rec in self:
     #           rec.share = user.is_user_profile or \
     #                        not user.has_group('base.group_user')



