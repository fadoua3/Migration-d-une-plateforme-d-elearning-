# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Question_ME(models.Model):
     _inherit ='survey.question'

     is_tm = fields.Boolean(string="Question ME")
     area_id = fields.Many2one('training.area', string='Area')
     domain_id = fields.Many2one('training.mode.domaine', string='Domain')
     group_ids = fields.Many2many('training.question.group', string='Group question')
     item_ids = fields.Many2many('training.item', string='Items')
     website_id = fields.Many2one('website', required=True)
     company_id = fields.Many2one('res.company', string='Company', required=True,
                                  default=lambda self: self.env.company)

