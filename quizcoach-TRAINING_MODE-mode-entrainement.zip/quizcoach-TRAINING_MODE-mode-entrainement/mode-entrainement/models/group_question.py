# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Group_question_ME(models.Model):

     _name ='training.question.group'
     _inherit = ['mail.thread']
     description = 'Training Mode group question'

     text = fields.Html(string='Text')
     name = fields.Char(string='Text')
     online = fields.Boolean(string='Online')
     image = fields.Binary(string='Image')
     attachment_ids = fields.Many2many('ir.attachment', string='Attachments')
     question_ids = fields.Many2many('survey.question', string='Questions')
     subject_ids = fields.Many2many('training.subject', string='Subject')
     item_ids = fields.Many2many('training.item', string='Items')
     domain_id = fields.Many2one('training.mode.domaine', string='Domain')
     website_id = fields.Many2one('website', required=True)
     company_id = fields.Many2one('res.company', string='Company', required=True,
                                  default=lambda self: self.env.company)



