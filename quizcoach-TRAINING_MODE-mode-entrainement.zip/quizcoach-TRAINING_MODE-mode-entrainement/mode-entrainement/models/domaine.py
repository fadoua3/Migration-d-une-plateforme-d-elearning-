# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Domain(models.Model):
    _name = 'training.mode.domaine'
    _description = 'domaine'

    name = fields.Char(string='Nom')
    website_id = fields.Many2one('website', required=True)
    data_base_id = fields.One2many('training.mode.database', 'domaine_id', string='Base de données')
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company)