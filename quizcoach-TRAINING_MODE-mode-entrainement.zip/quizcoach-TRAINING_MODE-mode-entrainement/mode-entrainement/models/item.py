# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Item(models.Model):
    _name = 'training.item'
    _description = 'item'

    name = fields.Char(string='Nom')
    question_ids = fields.Many2many('survey.question')
    group_ids = fields.Many2many('training.question.group', string='Groups')
    website_id = fields.Many2one('website', required=True)
    company_id = fields.Many2one('res.company', string='Company', required=True,
                                 default=lambda self: self.env.company)

