# -*- coding: utf-8 -*-
# from odoo import http


# class ModeEntrainement(http.Controller):
#     @http.route('/mode_entrainement/mode_entrainement/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/mode_entrainement/mode_entrainement/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('mode_entrainement.listing', {
#             'root': '/mode_entrainement/mode_entrainement',
#             'objects': http.request.env['mode_entrainement.mode_entrainement'].search([]),
#         })

#     @http.route('/mode_entrainement/mode_entrainement/objects/<model("mode_entrainement.mode_entrainement"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('mode_entrainement.object', {
#             'object': obj
#         })
